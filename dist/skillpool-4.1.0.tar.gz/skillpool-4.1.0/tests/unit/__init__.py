"""SkillPool unit tests."""
