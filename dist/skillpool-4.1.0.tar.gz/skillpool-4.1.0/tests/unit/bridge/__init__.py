"""Bridge module tests."""
