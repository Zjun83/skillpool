"""SkillPool test fixtures package."""
