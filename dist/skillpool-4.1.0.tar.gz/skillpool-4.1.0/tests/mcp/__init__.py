"""SkillPool MCP server tests."""
