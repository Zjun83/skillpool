"""SkillPool integration tests."""
