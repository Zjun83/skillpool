"""SkillPool test suite."""
